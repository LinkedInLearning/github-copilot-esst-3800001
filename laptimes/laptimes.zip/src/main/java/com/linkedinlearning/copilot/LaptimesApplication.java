package com.linkedinlearning.copilot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LaptimesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LaptimesApplication.class, args);
	}

}
