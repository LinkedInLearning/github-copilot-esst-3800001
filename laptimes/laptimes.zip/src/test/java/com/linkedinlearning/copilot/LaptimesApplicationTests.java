package com.linkedinlearning.copilot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptimesApplicationTests {

	@Test
	void contextLoads() {
	}

}
